import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { Shield, AlertTriangle, CheckCircle, Mail } from 'lucide-react';

const EmailChecker: React.FC = () => {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const checkEmail = async () => {
    if (!email.trim()) return;
    
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const isValidFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      const suspiciousPatterns = [
        'noreply@security-alert',
        'admin@bank-verification',
        'support@paypal-security',
        'no-reply@amazon-security'
      ];
      
      const isSuspicious = suspiciousPatterns.some(pattern => 
        email.toLowerCase().includes(pattern)
      );
      
      let status, message, color;
      
      if (!isValidFormat) {
        status = 'invalid';
        message = 'Invalid email format';
        color = 'red';
      } else if (isSuspicious) {
        status = 'suspicious';
        message = 'This email pattern is commonly used in phishing attempts';
        color = 'red';
      } else {
        status = 'safe';
        message = 'Email format appears legitimate';
        color = 'green';
      }
      
      setResult({ status, message, color });
      setLoading(false);
    }, 1500);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5" />
          Email Security Check
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            type="email"
            placeholder="Enter email address to check..."
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1"
          />
          <Button 
            onClick={checkEmail} 
            disabled={loading || !email.trim()}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
          >
            {loading ? 'Checking...' : 'Check Email'}
          </Button>
        </div>
        
        {result && (
          <Alert className={`border-${result.color}-200 bg-${result.color}-50`}>
            <div className="flex items-center gap-2">
              {result.status === 'safe' ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertTriangle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={`text-${result.color}-800`}>
                {result.message}
              </AlertDescription>
            </div>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};

export default EmailChecker;