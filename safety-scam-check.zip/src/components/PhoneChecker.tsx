import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { Shield, AlertTriangle, CheckCircle, Phone } from 'lucide-react';

const PhoneChecker: React.FC = () => {
  const [phone, setPhone] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const checkPhone = async () => {
    if (!phone.trim()) return;
    
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const cleanPhone = phone.replace(/\D/g, '');
      const suspiciousPatterns = [
        '1234567890',
        '0000000000',
        '1111111111',
        '9999999999'
      ];
      
      const isSuspicious = suspiciousPatterns.includes(cleanPhone) ||
        cleanPhone.length < 10 ||
        /^(\d)\1{9,}$/.test(cleanPhone);
      
      const isValidLength = cleanPhone.length >= 10 && cleanPhone.length <= 15;
      
      let status, message, color;
      
      if (!isValidLength) {
        status = 'invalid';
        message = 'Invalid phone number length';
        color = 'red';
      } else if (isSuspicious) {
        status = 'suspicious';
        message = 'This phone number pattern appears suspicious';
        color = 'red';
      } else {
        status = 'safe';
        message = 'Phone number format appears legitimate';
        color = 'green';
      }
      
      setResult({ status, message, color });
      setLoading(false);
    }, 1500);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="h-5 w-5" />
          Phone Security Check
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            type="tel"
            placeholder="Enter phone number to check..."
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="flex-1"
          />
          <Button 
            onClick={checkPhone} 
            disabled={loading || !phone.trim()}
            className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
          >
            {loading ? 'Checking...' : 'Check Phone'}
          </Button>
        </div>
        
        {result && (
          <Alert className={`border-${result.color}-200 bg-${result.color}-50`}>
            <div className="flex items-center gap-2">
              {result.status === 'safe' ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertTriangle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={`text-${result.color}-800`}>
                {result.message}
              </AlertDescription>
            </div>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
};

export default PhoneChecker;