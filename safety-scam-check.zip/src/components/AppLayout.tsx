import React from 'react';
import Hero from './Hero';
import LinkChecker from './LinkChecker';
import EmailChecker from './EmailChecker';
import PhoneChecker from './PhoneChecker';
import SafetyTips from './SafetyTips';

const AppLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8 space-y-16">
        {/* Hero Section */}
        <section>
          <Hero />
        </section>
        
        {/* Security Checkers Section */}
        <section className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-white/20">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Security Scanners
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Use our advanced security tools to verify links, emails, and phone numbers before engaging with them.
            </p>
          </div>
          
          <div className="space-y-8">
            <LinkChecker />
            <EmailChecker />
            <PhoneChecker />
          </div>
        </section>
        
        {/* Safety Tips Section */}
        <section>
          <SafetyTips />
        </section>
        
        {/* Footer */}
        <footer className="text-center py-8 border-t border-gray-200">
          <p className="text-gray-500 text-sm">
            © 2025 CyberGuard. Protecting you from digital threats.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default AppLayout;