import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, ShieldAlert, ShieldCheck, Link, Search } from 'lucide-react';

interface LinkResult {
  url: string;
  status: 'safe' | 'suspicious' | 'checking';
  risk: string;
  details: string;
}

const LinkChecker: React.FC = () => {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<LinkResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);

  const checkLink = async () => {
    if (!url.trim()) return;
    
    setIsChecking(true);
    setResult({ url, status: 'checking', risk: '', details: '' });
    
    // Simulate API call with mock data
    setTimeout(() => {
      const isSuspicious = Math.random() > 0.7;
      const newResult: LinkResult = {
        url,
        status: isSuspicious ? 'suspicious' : 'safe',
        risk: isSuspicious ? 'High Risk' : 'Low Risk',
        details: isSuspicious 
          ? 'This link has been flagged by multiple security databases'
          : 'This link appears to be safe based on our security checks'
      };
      setResult(newResult);
      setIsChecking(false);
    }, 2000);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <div className="flex gap-2">
        <Input
          placeholder="Paste suspicious link here..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          className="flex-1"
        />
        <Button 
          onClick={checkLink} 
          disabled={!url.trim() || isChecking}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          {isChecking ? <Search className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
          Check
        </Button>
      </div>
      
      {result && (
        <Card className="border-2 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link className="w-5 h-5" />
              Link Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 break-all">{result.url}</span>
              <Badge 
                variant={result.status === 'safe' ? 'default' : result.status === 'suspicious' ? 'destructive' : 'secondary'}
                className="flex items-center gap-1"
              >
                {result.status === 'safe' && <ShieldCheck className="w-3 h-3" />}
                {result.status === 'suspicious' && <ShieldAlert className="w-3 h-3" />}
                {result.status === 'checking' && <Search className="w-3 h-3 animate-spin" />}
                {result.status === 'checking' ? 'Checking...' : result.risk}
              </Badge>
            </div>
            <p className="text-sm">{result.details}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default LinkChecker;