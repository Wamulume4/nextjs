import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Eye, CreditCard, MessageSquare } from 'lucide-react';

const SafetyTips: React.FC = () => {
  const tips = [
    {
      icon: <AlertTriangle className="w-5 h-5 text-red-500" />,
      title: "Red Flags to Watch",
      content: "Urgent requests for money, poor grammar, too-good-to-be-true offers, and pressure to act quickly."
    },
    {
      icon: <Eye className="w-5 h-5 text-blue-500" />,
      title: "Verify Before You Trust",
      content: "Always double-check URLs, sender information, and contact companies directly through official channels."
    },
    {
      icon: <CreditCard className="w-5 h-5 text-green-500" />,
      title: "Secure Payment Methods",
      content: "Use secure payment platforms, avoid wire transfers to strangers, and never share banking details via email."
    },
    {
      icon: <MessageSquare className="w-5 h-5 text-purple-500" />,
      title: "Trust Your Instincts",
      content: "If something feels off, it probably is. Take time to research and consult with trusted friends or family."
    }
  ];

  return (
    <div className="w-full max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
        Stay Safe Online
      </h2>
      <div className="grid md:grid-cols-2 gap-6">
        {tips.map((tip, index) => (
          <Card key={index} className="border-l-4 border-l-gradient-to-b from-blue-500 to-purple-500 hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-3 text-lg">
                {tip.icon}
                {tip.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm leading-relaxed">{tip.content}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default SafetyTips;