import React from 'react';
import { Shield, Zap, Users, Lock, Mail, Phone, Link } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const Hero: React.FC = () => {
  return (
    <div className="text-center space-y-8">
      <div className="space-y-4">
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl shadow-lg">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            CyberGuard
          </h1>
        </div>
        <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto">
          Your digital shield against online scams and fraudulent transactions
        </p>
        <p className="text-lg text-gray-500 max-w-2xl mx-auto">
          Verify links, emails, and phone numbers instantly to protect yourself from digital threats
        </p>
      </div>
      
      <div className="grid md:grid-cols-3 gap-6 mt-12">
        <Card className="border-2 hover:shadow-lg transition-all duration-300 hover:scale-105">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Link className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Link Scanner</h3>
            <p className="text-gray-600 text-sm">Analyze suspicious URLs for malware and phishing attempts</p>
          </CardContent>
        </Card>
        
        <Card className="border-2 hover:shadow-lg transition-all duration-300 hover:scale-105">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Email Verification</h3>
            <p className="text-gray-600 text-sm">Check email addresses for phishing patterns and legitimacy</p>
          </CardContent>
        </Card>
        
        <Card className="border-2 hover:shadow-lg transition-all duration-300 hover:scale-105">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-2">Phone Checker</h3>
            <p className="text-gray-600 text-sm">Validate phone numbers and detect suspicious patterns</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Hero;