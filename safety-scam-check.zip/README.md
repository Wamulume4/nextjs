# CyberGuard - Digital Safety App

CyberGuard is a comprehensive digital safety application that helps people avoid online scams, especially when dealing with money transactions. The app provides instant security analysis for links, emails, and phone numbers.

## Features

- **Link Checker**: Paste any URL to instantly see if it has been flagged as safe or suspicious
- **Email Checker**: Verify email addresses for potential scam indicators
- **Phone Number Checker**: Analyze phone numbers for suspicious patterns
- **Safety Tips**: Educational content about online security best practices

## How to Access CyberGuard

### Option 1: Direct URL Access
If you've deployed CyberGuard to a hosting platform, users can access it directly through the URL:
- **Netlify**: `https://your-app-name.netlify.app`
- **Vercel**: `https://your-app-name.vercel.app`
- **GitHub Pages**: `https://yourusername.github.io/cyberguard`

### Option 2: Share the Link
1. Copy your deployment URL
2. Share it via:
   - Social media platforms
   - Email campaigns
   - QR codes for mobile access
   - Business cards or flyers

### Option 3: SEO and Discovery
1. **Search Engine Optimization**:
   - Submit your site to Google Search Console
   - Add meta descriptions and keywords
   - Create quality content about digital safety

2. **Social Media Presence**:
   - Create accounts on Twitter, Facebook, LinkedIn
   - Share safety tips and promote the tool
   - Use hashtags like #DigitalSafety #ScamPrevention

### Option 4: App Store Distribution
For wider reach, consider:
- Converting to a Progressive Web App (PWA)
- Publishing to mobile app stores
- Creating browser extensions

## Development

```bash
npm install
npm run dev
```

## Building for Production

```bash
npm run build
```

## Deployment

The built files in the `dist` folder can be deployed to any static hosting service.

---

**Stay Safe Online with CyberGuard!** 🛡️